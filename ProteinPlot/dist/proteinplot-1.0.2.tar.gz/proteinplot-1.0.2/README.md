# ProtPlot

### Install this package using the following command
* pip install ProteinPlot

### After installing open jupyter-lab and load in the example file
* jupyter-lab
